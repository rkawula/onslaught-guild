$(document).ready(function() {
    $('#calendar').fullCalendar({
        // put your options and callbacks here
    })
});
